package com.n1.smsreader;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** ফোন রিস্টার্টের পর ব্যাকগ্রাউন্ড চেক আবার চালু করে */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        RetryJob.scheduleHeartbeat(ctx);
        if (Store.queueSize(ctx) > 0) RetryJob.schedule(ctx);
    }
}

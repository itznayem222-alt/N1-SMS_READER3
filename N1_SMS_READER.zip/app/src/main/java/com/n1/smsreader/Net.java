package com.n1.smsreader;

import android.content.Context;
import android.os.Build;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** সার্ভারের সাথে কথা বলার সব কাজ */
final class Net {
    static final int OK = 0, FAIL_NET = 1, FAIL_AUTH = 2, FAIL_OTHER = 3;

    static final class Res {
        int code;
        String msg = "";
        boolean approved, dup;
    }

    static String base(String url) {
        String u = url == null ? "" : url.trim();
        u = u.replaceAll("/+$", "");
        u = u.replaceAll("/api/sms(/ping)?$", "");
        if (!u.isEmpty() && !u.startsWith("http")) u = "https://" + u;
        return u;
    }

    /** "N1-xxxx" কানেক্ট কোড থেকে {url, key} বের করে; না পারলে null */
    static String[] decodeCode(String text) {
        try {
            Matcher m = Pattern.compile("N1-([A-Za-z0-9_\\-=]+)").matcher(text == null ? "" : text);
            if (!m.find()) return null;
            String b = m.group(1);
            while (b.length() % 4 != 0) b += "=";
            JSONObject o = new JSONObject(new String(Base64.decode(b, Base64.URL_SAFE), "UTF-8"));
            String u = base(o.optString("u")), k = o.optString("k");
            if (u.isEmpty() || k.isEmpty()) return null;
            return new String[]{u, k};
        } catch (Exception e) {
            return null;
        }
    }

    private static Res call(String method, String url, String key, JSONObject body) {
        Res r = new Res();
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(9000);
            c.setRequestMethod(method);
            c.setRequestProperty("X-SMS-Key", key);
            c.setRequestProperty("User-Agent", "N1-SMS-Reader/1.0");
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                OutputStream os = c.getOutputStream();
                os.write(body.toString().getBytes("UTF-8"));
                os.close();
            }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String txt = "";
            if (in != null) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[2048];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                txt = bo.toString("UTF-8");
            }
            if (code == 401 || code == 403) { r.code = FAIL_AUTH; r.msg = "Key ভুল"; return r; }
            if (code == 429) { r.code = FAIL_NET; r.msg = "অনেক রিকোয়েস্ট"; return r; }
            if (code >= 500) { r.code = FAIL_NET; r.msg = "সার্ভার সমস্যা (" + code + ")"; return r; }
            if (code >= 400) { r.code = FAIL_OTHER; r.msg = "ত্রুটি " + code; return r; }
            try {
                JSONObject j = new JSONObject(txt);
                if (!j.optBoolean("ok", false)) { r.code = FAIL_OTHER; r.msg = j.optString("error", "অজানা উত্তর"); return r; }
                r.approved = j.optBoolean("approved", false);
                r.dup = j.optBoolean("duplicate", false);
            } catch (Exception e) {
                r.code = FAIL_OTHER; r.msg = "এটা N1 সার্ভার না (লিংক ঠিক আছে?)"; return r;
            }
            r.code = OK;
            return r;
        } catch (Exception e) {
            r.code = FAIL_NET;
            r.msg = "ইন্টারনেট/সার্ভার পাওয়া যায়নি";
            return r;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    static Res ping(String url, String key) {
        try {
            return call("GET", base(url) + "/api/sms/ping?key=" + URLEncoder.encode(key, "UTF-8"), key, null);
        } catch (Exception e) {
            Res r = new Res(); r.code = FAIL_OTHER; r.msg = "লিংক ঠিক নেই"; return r;
        }
    }

    static Res send(Context c, JSONObject p) {
        return call("POST", base(Store.url(c)) + "/api/sms", Store.key(c), p);
    }

    static JSONObject payload(Context c, String sender, String body, Parser.Tx x) {
        try {
            JSONObject p = new JSONObject();
            p.put("app", "n1");
            p.put("key", Store.key(c));
            p.put("message", body);
            p.put("from", sender);
            p.put("method", x.method);
            p.put("amount", x.amount);
            p.put("trx", x.trx);
            p.put("device", Build.MODEL);
            return p;
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    /** একটা শনাক্ত হওয়া লেনদেন সাথে সাথে সার্ভারে পাঠায়; ফেল করলে queue-তে রেখে পরে আবার চেষ্টা */
    static Res deliver(Context c, String sender, String body, Parser.Tx x) {
        Store.addLog(c, x.trx, x.method, x.amount, "sending", "");
        if (!Store.configured(c)) {
            Store.enqueue(c, payload(c, sender, body, x));
            Store.addLog(c, x.trx, x.method, x.amount, "queued", "সার্ভার কানেক্ট করা হয়নি");
            Res r = new Res(); r.code = FAIL_OTHER; return r;
        }
        Res r = null;
        for (int i = 0; i < 2; i++) {
            r = send(c, payload(c, sender, body, x));
            if (r.code != FAIL_NET) break;
        }
        if (r.code == OK) {
            Store.addLog(c, x.trx, x.method, x.amount, "sent", r.dup ? "আগেই পাঠানো" : "");
        } else if (r.code == FAIL_NET) {
            Store.enqueue(c, payload(c, sender, body, x));
            Store.addLog(c, x.trx, x.method, x.amount, "queued", r.msg);
            RetryJob.schedule(c);
        } else {
            Store.addLog(c, x.trx, x.method, x.amount, "failed", r.msg);
        }
        return r;
    }

    /** অপেক্ষমান সবগুলো আবার পাঠায়; কতগুলো গেল তা ফেরত দেয় */
    static int flush(Context c) {
        if (!Store.configured(c)) return 0;
        JSONArray q = Store.takeQueue(c);
        int ok = 0;
        for (int i = 0; i < q.length(); i++) {
            JSONObject p = q.optJSONObject(i);
            if (p == null) continue;
            String trx = p.optString("trx"), m = p.optString("method");
            double a = p.optDouble("amount");
            try { p.put("key", Store.key(c)); } catch (Exception ignored) { }
            Res r = send(c, p);
            if (r.code == OK) {
                ok++;
                Store.addLog(c, trx, m, a, "sent", "");
            } else if (r.code == FAIL_NET) {
                Store.enqueue(c, p);
            } else {
                Store.addLog(c, trx, m, a, "failed", r.msg);
            }
        }
        return ok;
    }
}

package com.n1.smsreader;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import java.util.LinkedHashMap;
import java.util.Map;

/** SMS আসার সাথে সাথে চলে। বিকাশ/নগদ/রকেটের টাকা পাওয়ার SMS ছাড়া সবকিছু চুপচাপ ইগনোর করে */
public class SmsReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context ctx, Intent intent) {
        if (intent == null || !Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        if (!Store.enabled(ctx)) return;
        SmsMessage[] parts = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (parts == null || parts.length == 0) return;

        // একই সেন্ডারের ভাঙা (multi-part) মেসেজ জোড়া লাগাই
        final Map<String, StringBuilder> msgs = new LinkedHashMap<>();
        for (SmsMessage m : parts) {
            if (m == null) continue;
            String from = m.getOriginatingAddress() == null ? "" : m.getOriginatingAddress();
            StringBuilder sb = msgs.get(from);
            if (sb == null) { sb = new StringBuilder(); msgs.put(from, sb); }
            sb.append(m.getMessageBody() == null ? "" : m.getMessageBody());
        }

        final String allowed = Store.senders(ctx);
        final Map<String, Parser.Tx> hits = new LinkedHashMap<>();
        for (Map.Entry<String, StringBuilder> e : msgs.entrySet()) {
            Parser.Tx x = Parser.detect(e.getKey(), e.getValue().toString(), allowed);
            if (x != null) hits.put(e.getKey(), x);
        }
        if (hits.isEmpty()) return;   // অন্য কোনো মেসেজ → কিছুই করে না

        final PendingResult pr = goAsync();
        final Context app = ctx.getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    for (Map.Entry<String, Parser.Tx> e : hits.entrySet()) {
                        Net.deliver(app, e.getKey(), msgs.get(e.getKey()).toString(), e.getValue());
                    }
                    if (Store.queueSize(app) > 0) RetryJob.schedule(app);
                    else Net.flush(app);
                } catch (Exception ignored) {
                } finally {
                    pr.finish();
                }
            }
        }).start();
    }
}

package com.n1.smsreader;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int BG = 0xFF0B1020, CARD = 0xFF151C33, CARD2 = 0xFF1D2745, SUB = 0xFF9AA6C8;
    static final int BLUE = 0xFF3B82F6, VIOLET = 0xFF8B5CF6, GREEN = 0xFF22C55E, RED = 0xFFEF4444, AMBER = 0xFFF59E0B;
    static final int PINK = 0xFFE2136E, ORANGE = 0xFFF6921E, PURPLE = 0xFF8C3494, GRAY = 0xFF2A3558;
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    static final String[] PERMS = {Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS};

    LinearLayout root, statusBox, statsBox, listBox, manualBox, advBox;
    TextView toggleBtn, permBtn;
    EditText etUrl, etKey, etSenders;
    final Handler h = new Handler(Looper.getMainLooper());
    String lastSig = "";

    final Runnable tick = new Runnable() {
        @Override public void run() {
            refresh();
            h.postDelayed(this, 2500);
        }
    };

    // ================= জীবনচক্র =================
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(BG);
        w.setNavigationBarColor(BG);
        build();
        RetryJob.scheduleHeartbeat(this);
        if (Store.queueSize(this) > 0) RetryJob.schedule(this);
    }

    @Override protected void onResume() { super.onResume(); lastSig = ""; h.post(tick); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tick); }

    // ================= UI helper =================
    int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    GradientDrawable shape(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    GradientDrawable grad(int c1, int c2, float r) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        g.setCornerRadius(dp(r));
        return g;
    }

    LinearLayout.LayoutParams lp(int w, int hgt, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, hgt);
        p.topMargin = dp(top);
        return p;
    }

    TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    void press(final View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View x, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) x.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start();
                else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL)
                    x.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                return false;
            }
        });
    }

    /** বড় সুন্দর বাটন (সহজে চাপা যায়: উচ্চতা কমপক্ষে ৬৪dp) */
    TextView btn(String label, int c1, int c2, View.OnClickListener l) {
        TextView t = text(label, 18, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setMinHeight(dp(64));
        t.setPadding(dp(16), dp(12), dp(16), dp(12));
        Drawable bg = grad(c1, c2, 20);
        t.setBackground(new RippleDrawable(ColorStateList.valueOf(0x55FFFFFF), bg, null));
        t.setClickable(true);
        t.setOnClickListener(l);
        t.setLayoutParams(lp(MATCH, WRAP, 12));
        press(t);
        return t;
    }

    /** পাশাপাশি দুই বাটনের সারি */
    LinearLayout pair(TextView a, TextView b) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutParams(lp(MATCH, WRAP, 0));
        for (TextView t : new TextView[]{a, b}) {
            t.setTextSize(16);
            t.setMinHeight(dp(72));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, WRAP, 1f);
            p.topMargin = dp(12);
            p.leftMargin = dp(t == b ? 6 : 0);
            p.rightMargin = dp(t == a ? 6 : 0);
            t.setLayoutParams(p);
            r.addView(t);
        }
        return r;
    }

    LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        c.setBackground(shape(CARD, 24));
        c.setLayoutParams(lp(MATCH, WRAP, 16));
        return c;
    }

    EditText field(String hint, boolean secret) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF6B7799);
        e.setTextColor(Color.WHITE);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setPadding(dp(16), dp(12), dp(16), dp(12));
        e.setMinHeight(dp(56));
        e.setBackground(shape(CARD2, 16));
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        e.setLayoutParams(lp(MATCH, WRAP, 10));
        return e;
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    void msg(String title, String body) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("ঠিক আছে", null).show();
    }

    boolean hasPerm() {
        for (String p : PERMS) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) return false;
        return true;
    }

    // ================= স্ক্রিন বানানো =================
    void build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(32));
        sv.addView(root, new ViewGroup.LayoutParams(MATCH, WRAP));
        setContentView(sv);

        // ---- হেডার ----
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setPadding(dp(22), dp(24), dp(22), dp(24));
        head.setBackground(grad(VIOLET, BLUE, 28));
        head.addView(text("N1 SMS Reader", 30, Color.WHITE, true));
        TextView sub = text("বিকাশ · নগদ · রকেট লেনদেন SMS অটো-শনাক্ত করে N1 হোস্টিংয়ে ডিপোজিট যোগ করে", 14, 0xE6FFFFFF, false);
        sub.setLayoutParams(lp(MATCH, WRAP, 6));
        head.addView(sub);
        LinearLayout chips = new LinearLayout(this);
        chips.setLayoutParams(lp(MATCH, WRAP, 14));
        String[] names = {"bKash", "Nagad", "Rocket"};
        int[] cols = {PINK, ORANGE, PURPLE};
        for (int i = 0; i < 3; i++) {
            TextView c = text(names[i], 13, Color.WHITE, true);
            c.setPadding(dp(14), dp(6), dp(14), dp(6));
            c.setBackground(shape(cols[i], 14));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(WRAP, WRAP);
            p.rightMargin = dp(8);
            c.setLayoutParams(p);
            chips.addView(c);
        }
        head.addView(chips);
        head.setLayoutParams(lp(MATCH, WRAP, 0));
        root.addView(head);

        // ---- স্ট্যাটাস ----
        statusBox = card();
        root.addView(statusBox);

        // ---- চালু/বন্ধ ----
        toggleBtn = btn("", GREEN, GREEN, new View.OnClickListener() {
            @Override public void onClick(View v) {
                Store.setEnabled(MainActivity.this, !Store.enabled(MainActivity.this));
                refresh();
            }
        });
        toggleBtn.setMinHeight(dp(84));
        toggleBtn.setTextSize(20);
        toggleBtn.setLayoutParams(lp(MATCH, WRAP, 16));
        root.addView(toggleBtn);

        // ---- সেটআপ ----
        LinearLayout setup = card();
        setup.addView(text("সেটআপ (৩টা সহজ ধাপ)", 20, Color.WHITE, true));

        permBtn = btn("", BLUE, VIOLET, new View.OnClickListener() {
            @Override public void onClick(View v) { askPerm(); }
        });
        setup.addView(permBtn);

        setup.addView(btn("📋  ধাপ ২: কানেক্ট কোড পেস্ট করুন", 0xFF16A34A, 0xFF22C55E, new View.OnClickListener() {
            @Override public void onClick(View v) { pasteCode(); }
        }));
        TextView hint = text("N1 বটে /smshook লিখে কোডটা কপি করুন, তারপর উপরের বাটন চাপুন।", 13, SUB, false);
        hint.setLayoutParams(lp(MATCH, WRAP, 8));
        setup.addView(hint);

        TextView manualToggle = btn("✍️  ম্যানুয়ালি লিংক ও কী দেব", GRAY, GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) {
                manualBox.setVisibility(manualBox.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });
        manualToggle.setTextSize(15);
        manualToggle.setMinHeight(dp(56));
        setup.addView(manualToggle);

        manualBox = new LinearLayout(this);
        manualBox.setOrientation(LinearLayout.VERTICAL);
        manualBox.setVisibility(View.GONE);
        etUrl = field("সার্ভার লিংক (https://...)", false);
        etKey = field("গোপন কী (Key)", true);
        etUrl.setText(Store.url(this));
        etKey.setText(Store.key(this));
        manualBox.addView(etUrl);
        manualBox.addView(etKey);
        manualBox.addView(btn("💾  সেভ করুন", BLUE, VIOLET, new View.OnClickListener() {
            @Override public void onClick(View v) {
                String u = Net.base(etUrl.getText().toString()), k = etKey.getText().toString().trim();
                if (u.isEmpty() || k.isEmpty()) { toast("লিংক ও কী দুটোই দিন"); return; }
                Store.saveConn(MainActivity.this, u, k);
                etUrl.setText(u);
                testConn();
            }
        }));
        setup.addView(manualBox);

        setup.addView(btn("🔌  ধাপ ৩: কানেকশন টেস্ট করুন", AMBER, ORANGE, new View.OnClickListener() {
            @Override public void onClick(View v) { testConn(); }
        }));
        root.addView(setup);

        // ---- পরিসংখ্যান ----
        statsBox = new LinearLayout(this);
        statsBox.setOrientation(LinearLayout.HORIZONTAL);
        statsBox.setLayoutParams(lp(MATCH, WRAP, 16));
        root.addView(statsBox);

        // ---- অ্যাকশন ----
        LinearLayout acts = card();
        acts.addView(text("দরকারি বাটন", 20, Color.WHITE, true));
        acts.addView(pair(
            btn("🔄\nপুরোনো SMS সিঙ্ক", BLUE, VIOLET, new View.OnClickListener() {
                @Override public void onClick(View v) { syncOld(); }
            }),
            btn("⏳\nআবার পাঠান", AMBER, ORANGE, new View.OnClickListener() {
                @Override public void onClick(View v) { retryNow(); }
            })));
        acts.addView(pair(
            btn("🔋\nব্যাকগ্রাউন্ড অন", 0xFF0EA5E9, BLUE, new View.OnClickListener() {
                @Override public void onClick(View v) { batterySettings(); }
            }),
            btn("📤\nঅ্যাপ শেয়ার", PINK, VIOLET, new View.OnClickListener() {
                @Override public void onClick(View v) { shareApp(); }
            })));
        root.addView(acts);

        // ---- সর্বশেষ লেনদেন ----
        LinearLayout lc = card();
        lc.addView(text("সর্বশেষ লেনদেন SMS", 20, Color.WHITE, true));
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        lc.addView(listBox);
        TextView clr = btn("🗑  লগ মুছুন", GRAY, GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) { Store.clearLog(MainActivity.this); lastSig = ""; refresh(); }
        });
        clr.setTextSize(15);
        clr.setMinHeight(dp(52));
        lc.addView(clr);
        root.addView(lc);

        // ---- অ্যাডভান্সড ----
        LinearLayout adv = card();
        TextView advT = btn("⚙️  অ্যাডভান্সড সেটিংস", GRAY, GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) {
                advBox.setVisibility(advBox.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });
        advT.setTextSize(15);
        advT.setMinHeight(dp(56));
        advT.setLayoutParams(lp(MATCH, WRAP, 0));
        adv.addView(advT);
        advBox = new LinearLayout(this);
        advBox.setOrientation(LinearLayout.VERTICAL);
        advBox.setVisibility(View.GONE);
        TextView at = text("কোন সেন্ডার থেকে আসা SMS ধরবে (কমা দিয়ে লিখুন)। সাধারণত বদলানোর দরকার নেই। অন্য নাম্বার/নাম থেকে আসা SMS কখনো ধরা হয় না, তাই ভুয়া SMS দিয়ে ফাঁকি দেওয়া যায় না।", 13, SUB, false);
        at.setLayoutParams(lp(MATCH, WRAP, 12));
        advBox.addView(at);
        etSenders = field("bkash,nagad,rocket,16216,16167", false);
        etSenders.setText(Store.senders(this));
        advBox.addView(etSenders);
        advBox.addView(btn("💾  সেভ", BLUE, VIOLET, new View.OnClickListener() {
            @Override public void onClick(View v) {
                String s = etSenders.getText().toString().trim();
                if (s.isEmpty()) { s = Store.DEF_SENDERS; etSenders.setText(s); }
                Store.setSenders(MainActivity.this, s);
                toast("সেভ হয়েছে");
            }
        }));
        adv.addView(advBox);
        root.addView(adv);

        // ---- সাহায্য ----
        LinearLayout help = card();
        help.addView(text("পারমিশন না আসলে / SMS না ধরলে", 17, Color.WHITE, true));
        TextView ht = text("1) ফোন সেটিংস → অ্যাপ → N1 SMS Reader → ⋮ (তিন ডট) → \"Restricted settings অনুমতি দিন\" → তারপর পারমিশন দিন।\n2) 🔋 ব্যাকগ্রাউন্ড অন বাটন চেপে এই অ্যাপকে \"Unrestricted / No restrictions\" দিন।\n3) Xiaomi/Oppo/Vivo ফোনে \"Autostart\" চালু করুন।", 14, SUB, false);
        ht.setLayoutParams(lp(MATCH, WRAP, 8));
        help.addView(ht);
        TextView sett = btn("⚙️  অ্যাপ সেটিংস খুলুন", GRAY, GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) { openAppSettings(); }
        });
        sett.setTextSize(15);
        sett.setMinHeight(dp(56));
        help.addView(sett);
        root.addView(help);
    }

    // ================= রিফ্রেশ =================
    void refresh() {
        boolean perm = hasPerm(), conf = Store.configured(this), on = Store.enabled(this);
        int ping = Store.ping(this);

        permBtn.setText(perm ? "✅  ধাপ ১: SMS পারমিশন দেওয়া আছে" : "🔐  ধাপ ১: SMS পারমিশন দিন");
        permBtn.setBackground(new RippleDrawable(ColorStateList.valueOf(0x55FFFFFF),
                perm ? grad(0xFF16A34A, 0xFF22C55E, 20) : grad(BLUE, VIOLET, 20), null));

        toggleBtn.setText(on ? "✅  রিডার চালু আছে\n(ট্যাপ করলে বন্ধ হবে)" : "⛔  রিডার বন্ধ আছে\n(ট্যাপ করলে চালু হবে)");
        toggleBtn.setBackground(new RippleDrawable(ColorStateList.valueOf(0x55FFFFFF),
                on ? grad(0xFF16A34A, 0xFF22C55E, 24) : grad(0xFFB91C1C, RED, 24), null));

        statusBox.removeAllViews();
        statusBox.addView(text("অবস্থা", 20, Color.WHITE, true));
        statusBox.addView(row("SMS পারমিশন", perm ? "দেওয়া আছে" : "দেওয়া হয়নি", perm));
        statusBox.addView(row("সার্ভার", !conf ? "কানেক্ট করা হয়নি" : ping == 1 ? "কানেক্টেড ✓" : ping == 2 ? "সমস্যা — টেস্ট করুন" : "সেট আছে (টেস্ট করুন)", conf && ping != 2));
        statusBox.addView(row("রিডার", on ? "চালু" : "বন্ধ", on));
        int q = Store.queueSize(this);
        if (q > 0) statusBox.addView(row("অপেক্ষায় আছে", q + " টি SMS", false));

        JSONArray log = Store.log(this);
        String sig = log.toString() + "|" + q;
        if (sig.equals(lastSig)) return;
        lastSig = sig;

        long dayStart = System.currentTimeMillis() - 24L * 3600 * 1000;
        int det = 0, sent = 0, wait = 0;
        for (int i = 0; i < log.length(); i++) {
            JSONObject o = log.optJSONObject(i);
            if (o == null || o.optLong("t") < dayStart) continue;
            det++;
            String s = o.optString("s");
            if (s.equals("sent")) sent++;
            else if (s.equals("queued") || s.equals("sending")) wait++;
        }
        statsBox.removeAllViews();
        statsBox.addView(stat("শনাক্ত", det, BLUE, false));
        statsBox.addView(stat("পাঠানো", sent, GREEN, true));
        statsBox.addView(stat("অপেক্ষায়", wait, AMBER, true));

        listBox.removeAllViews();
        if (log.length() == 0) {
            TextView e = text("এখনো কোনো লেনদেন SMS আসেনি।\nবিকাশ/নগদ/রকেটে টাকা পাওয়ার SMS এলে এখানে দেখা যাবে।", 14, SUB, false);
            e.setLayoutParams(lp(MATCH, WRAP, 12));
            listBox.addView(e);
        }
        for (int i = 0; i < log.length() && i < 30; i++) {
            JSONObject o = log.optJSONObject(i);
            if (o != null) listBox.addView(txRow(o));
        }
    }

    View row(String label, String value, boolean ok) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setLayoutParams(lp(MATCH, WRAP, 12));
        View dot = new View(this);
        dot.setBackground(shape(ok ? GREEN : RED, 8));
        LinearLayout.LayoutParams dp1 = new LinearLayout.LayoutParams(dp(12), dp(12));
        dp1.rightMargin = dp(10);
        dot.setLayoutParams(dp1);
        r.addView(dot);
        TextView l = text(label, 16, Color.WHITE, false);
        l.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        r.addView(l);
        r.addView(text(value, 15, ok ? GREEN : 0xFFFCA5A5, true));
        return r;
    }

    View stat(String label, int n, int color, boolean margin) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), dp(16), dp(8), dp(16));
        b.setBackground(shape(CARD, 20));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, WRAP, 1f);
        p.leftMargin = dp(margin ? 10 : 0);
        b.setLayoutParams(p);
        b.addView(text(String.valueOf(n), 28, color, true));
        b.addView(text(label + " (২৪ঘ)", 12, SUB, false));
        return b;
    }

    static String fmt(double a) {
        return a == Math.floor(a) ? String.valueOf((long) a) : String.format(Locale.US, "%.2f", a);
    }

    View txRow(JSONObject o) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(12), dp(12), dp(12), dp(12));
        r.setBackground(shape(CARD2, 18));
        r.setLayoutParams(lp(MATCH, WRAP, 10));

        String m = o.optString("m");
        int col = m.equals("bKash") ? PINK : m.equals("Nagad") ? ORANGE : m.equals("Rocket") ? PURPLE : BLUE;
        TextView badge = text(m.isEmpty() ? "?" : m.substring(0, 1), 18, Color.WHITE, true);
        badge.setGravity(Gravity.CENTER);
        GradientDrawable oval = new GradientDrawable();
        oval.setShape(GradientDrawable.OVAL);
        oval.setColor(col);
        badge.setBackground(oval);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(44), dp(44));
        bp.rightMargin = dp(12);
        badge.setLayoutParams(bp);
        r.addView(badge);

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        mid.addView(text("৳" + fmt(o.optDouble("a")) + "  " + m, 17, Color.WHITE, true));
        mid.addView(text("TrxID: " + o.optString("trx"), 12, SUB, false));
        String when = new SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(new Date(o.optLong("t")));
        String note = o.optString("n");
        mid.addView(text(when + (note.isEmpty() ? "" : " · " + note), 11, SUB, false));
        r.addView(mid);

        String s = o.optString("s"), label;
        int c;
        switch (s) {
            case "sent": label = "✅ পাঠানো"; c = GREEN; break;
            case "queued": label = "⏳ অপেক্ষায়"; c = AMBER; break;
            case "failed": label = "❌ ব্যর্থ"; c = RED; break;
            default: label = "📡 পাঠাচ্ছে"; c = BLUE;
        }
        TextView chip = text(label, 12, c, true);
        chip.setPadding(dp(10), dp(6), dp(10), dp(6));
        chip.setBackground(shape((c & 0x00FFFFFF) | 0x33000000, 14));
        r.addView(chip);
        return r;
    }

    // ================= অ্যাকশন =================
    void askPerm() {
        if (hasPerm()) { toast("পারমিশন দেওয়া আছেই ✅"); return; }
        requestPermissions(PERMS, 11);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        lastSig = "";
        refresh();
        if (!hasPerm()) {
            new AlertDialog.Builder(this).setTitle("পারমিশন আসেনি")
                .setMessage("SMS পড়ার পারমিশন ছাড়া রিডার কাজ করবে না।\n\nসেটিংসে গিয়ে (⋮ → Restricted settings অনুমতি দিন) তারপর SMS পারমিশন চালু করুন।")
                .setPositiveButton("সেটিংস খুলুন", (d, w) -> openAppSettings())
                .setNegativeButton("পরে", null).show();
        }
    }

    void openAppSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
        } catch (Exception e) { toast("সেটিংস খোলা যায়নি"); }
    }

    void batterySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            toast("লিস্ট থেকে N1 SMS Reader → \"Don't optimize\" দিন");
        } catch (Exception e) { openAppSettings(); }
    }

    void pasteCode() {
        String s = "";
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip() != null && cm.getPrimaryClip().getItemCount() > 0) {
                ClipData.Item it = cm.getPrimaryClip().getItemAt(0);
                CharSequence cs = it.coerceToText(this);
                if (cs != null) s = cs.toString();
            }
        } catch (Exception ignored) { }
        String[] uk = Net.decodeCode(s.trim());
        if (uk == null) {
            msg("কানেক্ট কোড পাওয়া যায়নি", "প্রথমে N1 বটে /smshook লিখুন, কোডটায় চেপে কপি করুন, তারপর এখানে আবার চাপুন।");
            return;
        }
        Store.saveConn(this, uk[0], uk[1]);
        etUrl.setText(uk[0]);
        etKey.setText(uk[1]);
        testConn();
    }

    void testConn() {
        if (!Store.configured(this)) { msg("কানেক্ট করা হয়নি", "আগে ধাপ ২ করুন (কোড পেস্ট বা ম্যানুয়ালি লিংক/কী)।"); return; }
        toast("টেস্ট চলছে...");
        final Context c = this;
        final String u = Store.url(this), k = Store.key(this);
        new Thread(() -> {
            final Net.Res r = Net.ping(u, k);
            Store.setPing(c, r.code == Net.OK ? 1 : 2);
            if (r.code == Net.OK) Net.flush(c);
            runOnUiThread(() -> {
                lastSig = "";
                refresh();
                if (r.code == Net.OK) {
                    RetryJob.scheduleHeartbeat(c);
                    msg("✅ কানেক্ট হয়েছে", "N1 সার্ভারের সাথে সংযোগ ঠিক আছে।\n\nএখন থেকে বিকাশ/নগদ/রকেটে টাকা এলে SMS নিজে থেকেই সার্ভারে চলে যাবে।");
                } else {
                    msg("❌ কানেক্ট হয়নি", r.msg + "\n\nলিংক ও কী আবার চেক করুন। বটে /smshook দিয়ে নতুন কোড নিতে পারেন।");
                }
            });
        }).start();
    }

    void retryNow() {
        if (Store.queueSize(this) == 0) { toast("অপেক্ষায় কোনো SMS নেই"); return; }
        final Context c = this;
        toast("আবার পাঠানো হচ্ছে...");
        new Thread(() -> {
            final int ok = Net.flush(c);
            runOnUiThread(() -> { lastSig = ""; refresh(); toast(ok + " টি পাঠানো হয়েছে"); });
        }).start();
    }

    /** গত ৭২ ঘণ্টার ইনবক্স থেকে বিকাশ/নগদ/রকেটের SMS খুঁজে সার্ভারে পাঠায় (সার্ভার ডুপ্লিকেট নিজেই বাদ দেয়) */
    void syncOld() {
        if (!hasPerm()) { msg("পারমিশন লাগবে", "আগে ধাপ ১ করে SMS পারমিশন দিন।"); return; }
        if (!Store.configured(this)) { msg("কানেক্ট করা হয়নি", "আগে ধাপ ২ করুন।"); return; }
        toast("পুরোনো SMS খোঁজা হচ্ছে...");
        final Context c = this;
        new Thread(() -> {
            int found = 0, sent = 0;
            try (Cursor cur = getContentResolver().query(Uri.parse("content://sms/inbox"),
                    new String[]{"address", "body", "date"}, null, null, "date DESC")) {
                long since = System.currentTimeMillis() - 72L * 3600 * 1000;
                String allowed = Store.senders(c);
                int n = 0;
                while (cur != null && cur.moveToNext() && n++ < 400) {
                    if (cur.getLong(2) < since) break;
                    String a = cur.getString(0), b = cur.getString(1);
                    Parser.Tx x = Parser.detect(a, b, allowed);
                    if (x == null) continue;
                    found++;
                    if (Net.deliver(c, a, b, x).code == Net.OK) sent++;
                }
            } catch (Exception ignored) { }
            final int f = found, s = sent;
            runOnUiThread(() -> {
                lastSig = "";
                refresh();
                msg("সিঙ্ক শেষ", "গত ৩ দিনে " + f + " টি লেনদেন SMS পাওয়া গেছে, " + s + " টি সার্ভারে পাঠানো হয়েছে।");
            });
        }).start();
    }

    void shareApp() {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("application/vnd.android.package-archive");
            i.putExtra(Intent.EXTRA_STREAM, Uri.parse("content://" + getPackageName() + ".apk/N1-SMS-Reader.apk"));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "N1 SMS Reader শেয়ার করুন"));
        } catch (Exception e) { toast("শেয়ার করা যায়নি"); }
    }
}

package com.n1.smsreader;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** সব সেটিংস, লগ আর অপেক্ষমান (queue) SMS এখানে থাকে */
final class Store {
    static final String DEF_SENDERS = "bkash,nagad,rocket,16216,16167";

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("n1", Context.MODE_PRIVATE);
    }

    static String url(Context c) { return sp(c).getString("url", ""); }
    static String key(Context c) { return sp(c).getString("key", ""); }
    static boolean configured(Context c) { return !url(c).isEmpty() && !key(c).isEmpty(); }

    static void saveConn(Context c, String url, String key) {
        sp(c).edit().putString("url", url).putString("key", key).putInt("ping", 0).apply();
    }

    static boolean enabled(Context c) { return sp(c).getBoolean("on", true); }
    static void setEnabled(Context c, boolean v) { sp(c).edit().putBoolean("on", v).apply(); }

    static String senders(Context c) { return sp(c).getString("senders", DEF_SENDERS); }
    static void setSenders(Context c, String s) { sp(c).edit().putString("senders", s).apply(); }

    /** 0 = টেস্ট হয়নি, 1 = ঠিক আছে, 2 = সমস্যা */
    static int ping(Context c) { return sp(c).getInt("ping", 0); }
    static void setPing(Context c, int v) { sp(c).edit().putInt("ping", v).apply(); }

    // ---------------- লগ ----------------
    static synchronized JSONArray log(Context c) {
        try { return new JSONArray(sp(c).getString("log", "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    /** একই TrxID আগে থাকলে আপডেট হয়, না থাকলে সবার ওপরে যোগ হয় */
    static synchronized void addLog(Context c, String trx, String method, double amt, String status, String note) {
        try {
            JSONArray old = log(c);
            JSONArray out = new JSONArray();
            JSONObject me = new JSONObject();
            me.put("t", System.currentTimeMillis());
            me.put("trx", trx); me.put("m", method); me.put("a", amt);
            me.put("s", status); me.put("n", note == null ? "" : note);
            out.put(me);
            for (int i = 0; i < old.length() && out.length() < 60; i++) {
                JSONObject o = old.getJSONObject(i);
                if (!trx.equalsIgnoreCase(o.optString("trx"))) out.put(o);
            }
            sp(c).edit().putString("log", out.toString()).apply();
        } catch (Exception ignored) { }
    }

    static synchronized void clearLog(Context c) { sp(c).edit().putString("log", "[]").apply(); }

    // ---------------- অপেক্ষমান queue ----------------
    static synchronized void enqueue(Context c, JSONObject p) {
        try {
            JSONArray q = new JSONArray(sp(c).getString("q", "[]"));
            String trx = p.optString("trx");
            for (int i = 0; i < q.length(); i++) if (trx.equalsIgnoreCase(q.getJSONObject(i).optString("trx"))) return;
            q.put(p);
            JSONArray cut = new JSONArray();
            for (int i = Math.max(0, q.length() - 100); i < q.length(); i++) cut.put(q.get(i));
            sp(c).edit().putString("q", cut.toString()).apply();
        } catch (Exception ignored) { }
    }

    static synchronized JSONArray takeQueue(Context c) {
        JSONArray q;
        try { q = new JSONArray(sp(c).getString("q", "[]")); } catch (Exception e) { q = new JSONArray(); }
        sp(c).edit().putString("q", "[]").apply();
        return q;
    }

    static synchronized int queueSize(Context c) {
        try { return new JSONArray(sp(c).getString("q", "[]")).length(); } catch (Exception e) { return 0; }
    }
}

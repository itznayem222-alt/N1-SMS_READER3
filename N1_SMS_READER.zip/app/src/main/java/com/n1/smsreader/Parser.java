package com.n1.smsreader;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** শুধু বিকাশ / নগদ / রকেটের "টাকা পাওয়ার" SMS শনাক্ত করে; বাকি সব মেসেজ ইগনোর */
final class Parser {
    static final class Tx {
        String method = "";
        double amount;
        String trx = "";
    }

    private static final int CI = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Pattern IN = Pattern.compile("(received|cash\\s*in|credited|পেয়েছেন|ক্যাশ\\s*ইন)", CI);
    private static final Pattern AMT = Pattern.compile("(?:\\b(?:tk\\.?|bdt|taka)|৳)\\s*:?\\s*([0-9,]+(?:\\.[0-9]+)?)", CI);
    private static final Pattern AMT2 = Pattern.compile("amount\\s*:?\\s*(?:tk\\.?|bdt|৳)?\\s*([0-9,]+(?:\\.[0-9]+)?)", CI);
    private static final Pattern TRX = Pattern.compile("(?:trx\\s*id|txn\\s*id|transaction\\s*id|tran\\s*id)\\s*[:\\-#]?\\s*([A-Za-z0-9]{6,40})", CI);

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    /** সেন্ডারের নাম অনুমোদিত তালিকায় আছে কিনা (বিকাশ = "bKash", নগদ = "NAGAD", রকেট = "16216" ইত্যাদি) */
    static boolean senderOk(String sender, String allowed) {
        String s = norm(sender);
        if (s.isEmpty()) return false;
        for (String tok : allowed.split("[,\\s]+")) {
            String t = norm(tok);
            if (t.isEmpty()) continue;
            if (t.matches("[0-9]+") ? s.equals(t) : s.contains(t)) return true;
        }
        return false;
    }

    static Tx detect(String sender, String body, String allowedSenders) {
        if (body == null || !senderOk(sender, allowedSenders)) return null;
        String t = body.replaceAll("\\s+", " ").trim();
        if (!IN.matcher(t).find()) return null;
        Matcher m = TRX.matcher(t);
        if (!m.find()) return null;
        Tx x = new Tx();
        x.trx = m.group(1);
        Matcher a = AMT.matcher(t);
        if (!a.find()) {
            a = AMT2.matcher(t);
            if (!a.find()) return null;
        }
        try { x.amount = Double.parseDouble(a.group(1).replace(",", "")); } catch (Exception e) { return null; }
        if (x.amount <= 0) return null;
        String s = norm(sender), low = t.toLowerCase(Locale.ROOT);
        if (s.contains("bkash")) x.method = "bKash";
        else if (s.contains("nagad") || s.equals("16167")) x.method = "Nagad";
        else if (s.contains("rocket") || s.equals("16216")) x.method = "Rocket";
        else if (low.contains("bkash")) x.method = "bKash";
        else if (low.contains("nagad")) x.method = "Nagad";
        else if (low.contains("rocket")) x.method = "Rocket";
        return x;
    }
}

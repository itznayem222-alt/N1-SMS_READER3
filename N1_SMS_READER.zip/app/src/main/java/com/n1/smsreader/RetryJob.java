package com.n1.smsreader;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;

/** ইন্টারনেট এলে অপেক্ষমান SMS পাঠায় + প্রতি ১৫ মিনিটে সার্ভারকে জানায় "রিডার জীবিত" */
public class RetryJob extends JobService {
    static final int ID_RETRY = 1, ID_BEAT = 2;

    static void schedule(Context c) {
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            js.schedule(new JobInfo.Builder(ID_RETRY, new ComponentName(c, RetryJob.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setMinimumLatency(4000)
                    .build());
        } catch (Exception ignored) { }
    }

    static void scheduleHeartbeat(Context c) {
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js.getPendingJob(ID_BEAT) != null) return;
            js.schedule(new JobInfo.Builder(ID_BEAT, new ComponentName(c, RetryJob.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPeriodic(15 * 60 * 1000L)
                    .build());
        } catch (Exception ignored) { }
    }

    @Override
    public boolean onStartJob(final JobParameters params) {
        final Context c = getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                boolean again = false;
                try {
                    if (Store.configured(c)) {
                        if (params.getJobId() == ID_BEAT) Net.ping(Store.url(c), Store.key(c));
                        Net.flush(c);
                        again = Store.queueSize(c) > 0 && params.getJobId() == ID_RETRY;
                    }
                } catch (Exception ignored) { }
                jobFinished(params, again);
            }
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) { return true; }
}
